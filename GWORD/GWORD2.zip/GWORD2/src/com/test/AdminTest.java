package com.test;

import org.junit.Test;

import com.gd.action.AdminAction;
import com.gd.model.Activity;
import com.gd.model.Admin;
import com.gd.service.ActivityService;
import com.gd.service.AdminService;
import com.gd.service.impl.ActivityServiceImpl;
import com.gd.service.impl.AdminServiceImpl;

public class AdminTest {
	
	@Test
	public void AdminSave(){
		
		AdminService as = new AdminServiceImpl();
		
		Admin admin = new Admin();
		
		admin.setName("admin");
		admin.setPassword("admin");
		System.out.println("ll");
		as.Save(admin);
	}
	
	@Test
	public void tt(){
		AdminAction ac = new AdminAction();
		ac.Save();
	}
	
	@Test
	public void text(){
		System.out.println("lx");
		
		ActivityService ac = new ActivityServiceImpl();
		Activity at = new Activity();
		at.setName("dasd");
		System.out.println(at.getName());
		ac.save(at);
	}

}
