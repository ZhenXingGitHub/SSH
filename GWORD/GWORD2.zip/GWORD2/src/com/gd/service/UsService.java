package com.gd.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.gd.model.Admin;
import com.gd.model.Us;

public interface UsService {

	public List<Us> findAll();
	
	public Us findEnty();
	
	public void updateEnty(Us u);
	
	public Us getEnty(Serializable id);
}
