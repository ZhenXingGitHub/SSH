package com.gd.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gd.dao.BaseDao;
import com.gd.model.Activity;
import com.gd.service.ActivityService;

@Service("activityService")
public class ActivityServiceImpl implements ActivityService {
	
	@Resource
	private BaseDao baseDao;

	@Override
	public List<Activity> findAll() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Activity");
	}

	@SuppressWarnings("unchecked")
	@Override
	public Serializable save(Activity ac) {
		// TODO Auto-generated method stub
		return this.baseDao.save(ac);
	}

	@Override
	public void update(Activity ac) {
		// TODO Auto-generated method stub
		this.baseDao.update(ac);
	}

	@Override
	public Activity findEnty(Activity ac) {
		// TODO Auto-generated method stub]
		System.out.println("��Ѫ"+ac.getName());
		return (Activity) this.baseDao.get("from Activity where name=?", new Object[]{ac.getName()});
	}
	
	@Override
	public List<Activity> findEnty(Activity ac, int i) {
		// TODO Auto-generated method stub
		return  this.baseDao.find("from Activity where 1=1 and name like '%"+ac.getName()+"%' and zhuangtai="+i);
	}

	@Override
	public void delete(Activity ac) {
		// TODO Auto-generated method stub
		this.baseDao.delete(ac);
	}

	@Override
	public Activity findById(Serializable id) {
		// TODO Auto-generated method stub
		return (Activity) this.baseDao.get(Activity.class, id);
	}

	public List<Activity> findZT(Serializable i) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Activity where zhuangtai=? order by shijian desc",new Object[]{i});
	}

	@Override
	public List<Activity> PageList(int page) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Activity where zhuangtai=? order by shijian desc",new Object[]{1}, page,10);
	}



}
