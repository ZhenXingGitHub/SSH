package com.gd.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gd.dao.BaseDao;
import com.gd.model.Activity;
import com.gd.model.Nows;
import com.gd.model.Us;
import com.gd.model.User;
import com.gd.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService{

	@Resource
	private BaseDao baseDao;
	
	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from User order by shijian desc");
	}

	@Override
	public void delete(User u) {
		// TODO Auto-generated method stub
		User uu = (User) this.baseDao.get(User.class, u.getId());
		this.delete(uu);
	}

	@Override
	public User findByID(Serializable id) {
		// TODO Auto-generated method stub
		return (User) this.baseDao.get(User.class, id);
	}

	@Override
	public List<User> findEnty(User u) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from User where activity=? order by shijian desc", new Object[]{u.getActivity()});
	}

	@Override
	public List<User> PageList(int page) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from User order by shijian desc", new Object[]{}, page, 10);
	}

	@Override
	public List<User> findByCondition(User u) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from User where activity=? order by shijian desc", new Object[]{u.getActivity()});
	}

	@Override
	public List findActivity() {
		// TODO Auto-generated method stub
		return this.baseDao.find("select distinct name from Activity where zhuangtai=? order by fwflow desc", new Object[]{0});
		//return this.baseDao.find("select distinct name from Activity where zhuangtai=? order by fwflow desc", new Object[]{0});
	}

	@Override
	public Us findUs() {
		// TODO Auto-generated method stub
		return (Us) this.baseDao.findEnty("from Us");
	}

	@Override
	public Serializable save(User u) {
		// TODO Auto-generated method stub
		return this.baseDao.save(u);
	}

	@Override
	public List<Nows> findHotList() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where 1=1 and zhuangtai="+0+" order by fwflow desc");
	}

	@Override
	public List<Nows> findNowsList() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where zhuangtai=? order by shijian desc",new Object[]{0});
	}
	
	public List<Nows> pageNows(int page,String n){
		
		return this.baseDao.find("from Nows where zhuangtai=? order by "+n+" desc",new Object[]{0}, page,10);
	}

	public Nows findNows(Serializable id){
		
		
		return (Nows) this.baseDao.get(Nows.class, id);
	}

	@Override
	public Activity findAC(Serializable id) {
		// TODO Auto-generated method stub
		return (Activity) this.baseDao.get(Activity.class, id);
	}

	@Override
	public List<Activity> findAllAC() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Activity  where 1=1 and zhuangtai="+0+" order by fwflow desc");
	}
}
