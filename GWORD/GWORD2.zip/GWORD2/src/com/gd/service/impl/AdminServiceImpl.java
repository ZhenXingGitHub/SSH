package com.gd.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gd.dao.BaseDao;
import com.gd.model.Activity;
import com.gd.model.Admin;
import com.gd.model.Nows;
import com.gd.model.Us;
import com.gd.service.AdminService;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

	@Resource
	private BaseDao baseDao;



	@Override
	public void Save(Admin admin) {
		System.out.println("aas");
		baseDao.save(admin);
		
	}

	@Override
	public List<Admin> findAlluser() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Admin> login(Map<String, Object> map) {

		return null;
	}

	@Override
	public Admin findEnty(Admin admin) {
		
		return (Admin)this.baseDao.get("from Admin where name=? and password=?", new Object[]{admin.getName(), admin.getPassword()});
	}

	@Override
	public Long tdnum(String n) {
		// TODO Auto-generated method stub
		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String sj = dateFormat.format(now).substring(0, 10);
		return this.baseDao.count("select count(*) from "+n+" where 1=1 and shijian like '%"+sj+"%'");
	}

	@Override
	public Long allnum(String n) {
		// TODO Auto-generated method stub
		return this.baseDao.count("select count(*) from "+n);
	}

	@Override
	public List<Nows> findHotNows() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where 1=1 and zhuangtai="+0+" order by fwflow desc", 6);
	}

	@Override
	public List<Activity> findHotAC() {
		// TODO Auto-generated method stub
		return  this.baseDao.find("from Activity where 1=1 and zhuangtai="+0+" order by fwflow desc", 6);
	}

	
}
