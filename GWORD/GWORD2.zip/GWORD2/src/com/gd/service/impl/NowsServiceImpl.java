package com.gd.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gd.dao.BaseDao;
import com.gd.model.Activity;
import com.gd.model.Nows;
import com.gd.service.NowsService;

@Service("nowsService")
public class NowsServiceImpl implements NowsService{

	@Resource
	private BaseDao baseDao; 

	@Override
	public Serializable save(Nows n) {
		// TODO Auto-generated method stub
		return this.baseDao.save(n);
		
	}

	@Override
	public void update(Nows n) {
		// TODO Auto-generated method stub
		this.baseDao.update(n);
		
	}

	@Override
	public void delete(Nows n) {
		// TODO Auto-generated method stub
		this.baseDao.delete(n);
	}

	@Override
	public List<Nows> findAll() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows");
	}

	@Override
	public Nows findById(Serializable id) {
		// TODO Auto-generated method stub
		return (Nows) this.baseDao.get(Nows.class, id);
	}

	@Override
	public List<Nows> findEnty(Nows n) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where bigtitle=?", new Object[]{n.getBigtitle()});
	}

	@Override
	public Nows getEnty(Nows n) {
		// TODO Auto-generated method stub
		return (Nows) this.baseDao.get("from Nows where bigtitle=?", new Object[]{n.getBigtitle()});
	}

	@Override
	public List<Nows> findHotList() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where 1=1 and zhuangtai="+0+" order by fwflow desc", 6);
	}
	
	@Override
	public List<Nows> findByCondition(String condition,String values) {
		// TODO Auto-generated method stub
		System.out.println("��䡪��������������from Nows where 1=1 and "+condition+" like '%"+values+"%'");
		return this.baseDao.find("from Nows where 1=1 and "+condition+" like '%"+values+"%'");
	}
	
	@Override
	public List<Nows> findNowList(String condition, String values) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where 1=1 and zhuangtai="+0+" and "+condition+" like '%"+values+"%'");
	}
	
	@Override
	public List<Nows> findList(String sql,  Map<String,Object> values) {
		// TODO Auto-generated method stub
		System.out.println(values);
		return this.baseDao.findByCondition(sql, values);
	}
	
	public List<Nows> findZT(Serializable i) {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Nows where zhuangtai=? order by shijian desc",new Object[]{i});
	}

	@Override
	public List<Nows> findEntyCondition(String bigtitle, int zhuangtai) {
		// TODO Auto-generated method stub
		System.out.println("from Nows where 1=1 and bigtitle like '%"+bigtitle+"%' zhuangtai="+zhuangtai);
		return  this.baseDao.find("from Nows where 1=1 and bigtitle like '%"+bigtitle+"%' and zhuangtai="+zhuangtai);
	}

	@Override
	public List<Nows> PageList(int i, int page) {
		// TODO Auto-generated method stub
		return  this.baseDao.find("from Nows where zhuangtai=? order by shijian desc",new Object[]{i}, page,10);
	}

	

	
}
