package com.gd.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gd.dao.BaseDao;
import com.gd.model.Us;
import com.gd.service.UsService;

@Service("usService")
public class UsServiceImpl implements UsService {
	
	@Resource
	private BaseDao baseDao;

	@Override
	public List<Us> findAll() {
		// TODO Auto-generated method stub
		return this.baseDao.find("from Us");
	}

	@Override
	public Us findEnty() {
		// TODO Auto-generated method stub
		return (Us)this.baseDao.findEnty("from Us");
	}

	@Override
	public void updateEnty(Us u) {
		
		this.baseDao.update(u);
		
	}
	
	public Us getEnty(Serializable id){
		
		return (Us) this.baseDao.get(Us.class, id);
	}

}
