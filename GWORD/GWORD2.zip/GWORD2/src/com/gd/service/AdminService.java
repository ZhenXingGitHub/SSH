package com.gd.service;

import java.util.List;
import java.util.Map;

import com.gd.model.Activity;
import com.gd.model.Admin;
import com.gd.model.Nows;
import com.gd.model.Us;

public interface AdminService {

	public List<Admin> login(Map<String, Object> map);
	
	public void Save(Admin admin);
	
	public List<Admin> findAlluser();
	
	public Admin findEnty(Admin admin);
	
	public Long tdnum(String n);
	
	public Long allnum(String n);
	
	public List<Nows> findHotNows();
	
	public List<Activity> findHotAC();
	
}
