package com.gd.service;

import java.io.Serializable;
import java.util.List;

import com.gd.model.Activity;

public interface ActivityService {

	public List<Activity> findAll();
	
	public List<Activity> findZT(Serializable i);
	
	public Serializable save(Activity ac);
	
	public void update(Activity ac);
	
	public Activity findEnty(Activity ac);
	
	public List<Activity> findEnty(Activity ac,int i);
	
	public Activity findById(Serializable id);
	
	public void delete(Activity ac);
	
	public List<Activity> PageList(int page);
}
