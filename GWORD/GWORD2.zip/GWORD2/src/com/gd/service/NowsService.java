package com.gd.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.gd.model.Activity;
import com.gd.model.Nows;

public interface NowsService {

	public Serializable save(Nows n);
	
	public void update(Nows n);
	
	public void delete(Nows n);
	
	public List<Nows> findAll();
	
	public Nows findById(Serializable id);
	
	public List<Nows> findHotList();
	
	public List<Nows> findEnty(Nows n);
	
	public List<Nows> findList(String sql, Map<String,Object> values);
	
	public List<Nows> findByCondition(String condition,String values) ;
	
	public List<Nows> findNowList(String condition,String values) ;
	
	public Nows getEnty(Nows n);
	
	public List<Nows> findZT(Serializable i);
	
	public List<Nows> findEntyCondition(String bigtitle,int zhuangtai);
	
	public List<Nows> PageList(int i,int page);
}
