package com.gd.service;

import java.io.Serializable;
import java.util.List;

import com.gd.model.Activity;
import com.gd.model.Nows;
import com.gd.model.Us;
import com.gd.model.User;


public interface UserService {
	
	public Serializable save(User u);

	public List<User> findAll();
	
	public void delete(User u);
	
	public User findByID(Serializable id);
	
	public List<User> findEnty(User u);
	
	public List<User> PageList(int page);
	
	public List<User> findByCondition(User u);
	
	public List findActivity();
	
	public Us findUs();
	
	public List<Nows> findHotList();
	
	public List<Nows> findNowsList();
	
	public List<Nows> pageNows(int page,String n);
	
	public Nows findNows(Serializable id);
	
	public Activity findAC(Serializable id);
	
	public List<Activity> findAllAC();
}
