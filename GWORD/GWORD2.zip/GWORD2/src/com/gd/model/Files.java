package com.gd.model;

import java.io.File;

public class Files {
	
	private File file; // �ļ�
	
	private String fileFileName;  // �ļ���
	
	private String fileContentType;  // �ļ�����

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}
	
	

}
