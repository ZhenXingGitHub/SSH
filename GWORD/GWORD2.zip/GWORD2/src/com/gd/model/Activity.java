package com.gd.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.junit.ClassRule;
@Entity
@Table(name="g_activity")
public class Activity implements Serializable {

	private Integer id;
	private String name;
	private String describes;
	private String bigimg;
	private String smallimg;
	private String declaration;
	private int zhuangtai;//״̬  ɾ�����ִ�  0 1
	private String shijian;
	private Integer fwflow;

	@Id
	@GenericGenerator(name = "generator", strategy = "native")
	@GeneratedValue(generator = "generator")
	@Column(name = "id", length=11)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name = "name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name = "describes")
	public String getDescribes() {
		return describes;
	}
	public void setDescribes(String describes) {
		this.describes = describes;
	}
	@Column(name = "bigimg")
	public String getBigimg() {
		return bigimg;
	}
	public void setBigimg(String bigimg) {
		this.bigimg = bigimg;
	}
	@Column(name = "smallimg")
	public String getSmallimg() {
		return smallimg;
	}
	public void setSmallimg(String smallimg) {
		this.smallimg = smallimg;
	}
	@Column(name = "declaration")
	public String getDeclaration() {
		return declaration;
	}
	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}
	@Column(name = "zhuangtai")
	public int getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(int zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	@Column(name = "shijian")
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	@Column(name = "fwflow")
	public Integer getFwflow() {
		return fwflow;
	}
	public void setFwflow(Integer fwflow) {
		this.fwflow = fwflow;
	}
	@Override
	public String toString() {
		return "Activity [id=" + id + ", name=" + name + ", describes=" + describes + ", bigimg=" + bigimg
				+ ", smallimg=" + smallimg + ", declaration=" + declaration + ", zhuangtai=" + zhuangtai + ", shijian="
				+ shijian + ", fwflow=" + fwflow + "]";
	}
	
	
	
	
	
}
