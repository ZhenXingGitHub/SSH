package com.gd.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.opensymphony.xwork2.ActionSupport;
@Entity
@Table(name="g_nows")
public class Nows{

	@Override
	public String toString() {
		return "Nows [id=" + id + ", bigtitle=" + bigtitle + ", smalltitle=" + smalltitle + ", describes=" + describes
				+ ", zhuangtai=" + zhuangtai + ", fwflow=" + fwflow + ", img=" + img + ", imgs=" + imgs + ", shijian="
				+ shijian + "]";
	}
	private Integer id;
	private String bigtitle;//�����
	private String smalltitle;//С����
	private String describes;//����
	private int zhuangtai;//״̬
	private int fwflow;//��������
	private String  img;//xiao tu 
	private String imgs;
	private String shijian;//ʱ��
	
	@Id
	@GenericGenerator(name = "generator", strategy = "native")
	@GeneratedValue(generator = "generator")
	@Column(name = "id", length=11)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "bigtitle")
	public String getBigtitle() {
		return bigtitle;
	}
	public void setBigtitle(String bigtitle) {
		this.bigtitle = bigtitle;
	}
	
	@Column(name = "smalltitle")
	public String getSmalltitle() {
		return smalltitle;
	}
	public void setSmalltitle(String smalltitle) {
		this.smalltitle = smalltitle;
	}
	
	@Column(name = "describes")
	public String getDescribes() {
		return describes;
	}
	public void setDescribes(String describes) {
		this.describes = describes;
	}
	
	@Column(name = "zhuangtai")
	public int getZhuangtai() {
		return zhuangtai;
	}
	public void setZhuangtai(int zhuangtai) {
		this.zhuangtai = zhuangtai;
	}
	
	@Column(name = "fwflow")
	public int getFwflow() {
		return fwflow;
	}
	public void setFwflow(int fwflow) {
		this.fwflow = fwflow;
	}
	@Column(name = "img")
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	@Column(name = "imgs")
	public String getImgs() {
		return imgs;
	}
	public void setImgs(String imgs) {
		this.imgs = imgs;
	}
	
	@Column(name = "shijian")
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
}
