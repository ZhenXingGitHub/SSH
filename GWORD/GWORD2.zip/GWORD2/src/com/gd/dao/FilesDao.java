package com.gd.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

public class FilesDao {
	public String FileOneStream(String filename,String filetype,File file){
		
		 String root = ServletActionContext.getServletContext().getRealPath("/Back/assete/img");
		 System.out.println("filePath   "+root);
	        byte[] buffer = new byte[500];
	        int length = 0;
	        String name = filename+"."+filetype;
	        try {
	        	 InputStream is = new FileInputStream(file);
	 	        
	 	        OutputStream os = new FileOutputStream(new File(root, name));
	 	       
	 	        System.out.println("fileFileName: " + filename);

	 	        System.out.println("file: " + file.getName());
	 	        System.out.println("file: " + file.getPath());
				while(-1 != (length = is.read(buffer, 0, buffer.length)))
				{
				    os.write(buffer);
				}
				 os.close();
			     is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	       
		
		return " ";
	}
	
	public String FileOne(String filename,String filetype,File file){
		String url1=ServletActionContext.getServletContext().getRealPath("/Back/assete/img");
		File filePath=new File(url1);
		System.out.println("filePath   "+filePath);
		if(!filePath.exists()){
			filePath.mkdirs();
		}
		System.out.println("leixing"+filetype);
		String url=url1+"/"+String.valueOf(filename)+"."+String.valueOf(filetype);
		File file22=new File(url);
		System.out.println("filePaths   "+url);
		try {
			FileUtils.copyFile(file, file22);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return url;
	}
	
}
