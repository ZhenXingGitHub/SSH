package com.gd.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.gd.model.Activity;
import com.gd.model.Nows;
import com.gd.model.Page;
import com.gd.model.Us;
import com.gd.model.User;
import com.gd.service.UserService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@Controller
public class UserAction extends ActionSupport {
	
	private User user;
	@Resource
	private UserService userService;
	
	private Page page;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}
	
	public String save(){
		
		if(user.getActivity()=="ѡ��"){
			ActionContext.getContext().put("result", "ѡ��");
		}
		else if(user.getDescribes()==null||user.getName()==null||user.getTel()==null){
			ActionContext.getContext().put("result", "����Ϊ��");
		}
		else{
			Date now = new Date(); 
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			user.setShijian(dateFormat.format(now));
			userService.save(user);
		}
		return "save";
	}
	
	public String findAlllist(){
		
		List aclist = userService.findActivity();//��ѯ���л
		List<User> list = userService.findAll();
		page.setCurrentPage(page.countCurrentPage(page.getCurrentPage()));
		List<User> userlist = userService.PageList(page.getCurrentPage());//��ǰҳ����	
		int totalPage = page.countTotalPage(10, list.size());//�ж���ҳ��
		page.setTotalPage(totalPage);
		ActionContext.getContext().put("pp", page);
		ActionContext.getContext().put("alllist", list);
		ActionContext.getContext().put("ulist", userlist);
		ActionContext.getContext().put("aclist", aclist);
		return "user_alllist";
	}

	public String findlist(){
		
		List aclist = userService.findActivity();//��ѯ���л
		List<User> list = userService.findByCondition(user);
		ActionContext.getContext().put("ulist", list);
		ActionContext.getContext().put("pp", page);
		ActionContext.getContext().put("aclist", aclist);
		return "user_alllist";
	}
	
	public String index(){
		
		List aclist = userService.findActivity();//��ѯ���л
		List sulist = aclist.subList(0, 4);
		System.out.println(sulist);
		ActionContext.getContext().put("suaclist", sulist);
		String t = us();
		return "index";
	}
	
	public String activity(){
		
		List<Activity> list = userService.findAllAC();
		System.out.println(list);
		ActionContext.getContext().put("aclist", list);
		return "aclist";
	}
	
	public String findac(){
		
		int t = user.getId();
		Activity ac = userService.findAC(t);
		ActionContext.getContext().put("ac", ac);
		return "ac";
	}
	
	public String hotnows(){
		
		List<Nows> nows = userService.findHotList();
		ActionContext.getContext().put("hotnows", nows);
		ActionContext.getContext().put("nowsname", "�ȵ�����");
		return "hotnows";
	}
	
	public String nowslist(){
		
		List<Nows> list = userService.findNowsList();
		ActionContext.getContext().put("nowslist", list);
		ActionContext.getContext().put("nowsname", "��������");
		return "nowslist";
	}
	
	public String nows(){
		
		String t = hotnows();
		String tt = nowslist();
		return "nows";
	}
	
	public String findNows(){
		
		int t = user.getId();
		Nows n = userService.findNows(t);
		ActionContext.getContext().put("now", n);
		return "nowsdetails";
	}
	
	public String us(){
		
		Us us = userService.findUs();
		ActionContext.getContext().put("Us", us);
		System.out.println(us);
		return "us";
	}
	
	public String zixun(){
		
		List aclist = userService.findActivity();//��ѯ���л
		ActionContext.getContext().put("aclist", aclist);
		return "zixun";
	}
	
}
