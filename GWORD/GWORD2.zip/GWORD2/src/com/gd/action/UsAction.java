package com.gd.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.gd.model.Us;
import com.gd.service.UsService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@Controller
public class UsAction extends ActionSupport {

	private Us us;
	
	@Resource
	private UsService usService;

	public Us getUs() {
		return us;
	}

	public void setUs(Us us) {
		this.us = us;
	}
	
	public String findEnty(){
		Us u = usService.findEnty();
		System.out.println("Us      :"+u);
		ActionContext.getContext().put("u", u);
		return "us_list";
	}
	
	public  String update(){
		System.out.println("�޸�ID��"+us.getId());
		Us u = usService.getEnty(us.getId());
		u.setTel(us.getTel());
		u.setMiaoshu(us.getMiaoshu());
		u.setWeibo(us.getWeibo());
		u.setWeixin(us.getWeixin());
		u.setQq(us.getQq());
		System.out.println("�޸�"+u);
		usService.updateEnty(u);
		return "us_update";
	}
	
}
