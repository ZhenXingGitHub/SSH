package com.gd.action;

import com.opensymphony.xwork2.ActionSupport;

public class OtherAction extends ActionSupport {

	private int NowsNumber;
	
	private int TodayNowsNumber;
	

	
}
