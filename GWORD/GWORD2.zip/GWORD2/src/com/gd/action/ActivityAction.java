package com.gd.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.gd.model.Activity;
import com.gd.model.Page;
import com.gd.model.Us;
import com.gd.service.ActivityService;
import com.gd.service.UsService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@Controller
public class ActivityAction extends ActionSupport {

	@Resource
	private ActivityService activityService;
	
	private Activity activity;
	
	private Page page;

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public Activity getActivity() {
		return activity;
	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	public String save(){
		
		activityService.save(activity);
		return "save";
	}
	
	public String delete(){//ɾ�������浽ɾ���б�
		
		System.out.println("ɾ�������������������"+activity.getId());
		Activity act = activityService.findById(activity.getId());
		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		act.setShijian(dateFormat.format(now));
		act.setZhuangtai(1);
		System.out.println(act);
		activityService.update(act);
		return "activity_delete";
	}
	
	public String list(){//�����б�
		
		System.out.println("adsssssssss");
		List<Activity> activity = activityService.findZT(0);
		System.out.println("dasdasdasda");
		ActionContext.getContext().put("aclist", activity);
		return "activity_list";
	}
	
	public String deletelist(){//失效删除
		
		List<Activity> activity = activityService.findZT(1);
		page.setCurrentPage(page.countCurrentPage(page.getCurrentPage()));
		List<Activity> ac = activityService.PageList(page.getCurrentPage());
		int totalPage = page.countTotalPage(10, activity.size());
		page.setTotalPage(totalPage);
		ActionContext.getContext().put("aclist", ac);
		ActionContext.getContext().put("pp", page);
		ActionContext.getContext().put("acall", activity);
		System.out.println("yeshu"+page.getCurrentPage()+"___"+ac);
		return "activity_deletelist";
	}
	
	public String cddelete(){//����ɾ��
		
		Activity act = activityService.findById(activity.getId());
		activityService.delete(act);
		return "activity_cddelete";
	}
	
	public String findEnty(){
		
		List<Activity> act = activityService.findEnty(activity,0);
		ActionContext.getContext().put("aclist", act);
		return "activity_list";
	}
	
	public String findDeleteEnty(){
		
		ActionContext.getContext().put("pp", page);
		List<Activity> act = activityService.findEnty(activity,1);
		ActionContext.getContext().put("aclist", act);
		return "activity_deletelist";
	}
	
	public String findById(){
		
		System.out.println("���ҡ���������������������������ID"+activity.getId());
		Activity act = activityService.findById(activity.getId());
		ActionContext.getContext().put("acedit", act);
		return "activity_edit";
	}
	
	public String getEnty(){
		
		Activity act = activityService.findById(activity.getId());
		ActionContext.getContext().put("ace", act);
		return "activity_enty";
	}
	
	public String saveOrupdate(){//���� ����
		
		Date now = new Date(); 
		System.out.println("id____=++++"+activity.getId());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		activity.setShijian(dateFormat.format(now));
		if(activity.getId() == null){
			activityService.save(activity);
		}else{
			Activity act = activityService.findById(activity.getId());
			activityService.update(activity);
		}
		ActionContext.getContext().put("ace", activity);
		return "activity_enty";
		
	}
	
	public String recovery(){//�ָ�ɾ������
		
		Activity act = activityService.findById(activity.getId());
		act.setZhuangtai(0);
		activityService.update(act);
		ActionContext.getContext().put("ace", act);
		return "activity_enty";
	}
}
