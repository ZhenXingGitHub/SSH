package com.gd.action;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.gd.dao.FilesDao;
import com.gd.model.Activity;
import com.gd.model.Files;
import com.gd.model.Nows;
import com.gd.model.Page;
import com.gd.service.NowsService;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.sun.xml.internal.ws.api.pipe.Fiber;

@Controller
public class NowsAction {

	@Resource
	private NowsService nowsSerivce;
	
	private Nows nows;
	
	private Files files;
	
	public FilesDao filesDao = new FilesDao();
	
	public String[] filestype ={"jpg","bmp","png"}; 
	
	public boolean b = false;
	
	private Page page;

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	
	public Nows getNows() {
		return nows;
	}

	public void setNows(Nows nows) {
		this.nows = nows;
	}

	public Files getFiles() {
		return files;
	}

	public void setFiles(Files files) {
		this.files = files;
	}
	
	public String fileUpdate(String filetype){ 
		
		String url = filesDao.FileOne(nows.getBigtitle(), filetype, files.getFile());
		return url;
	}
	
	public String savaOrupdate(){

		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		nows.setShijian(dateFormat.format(now));
		String filetype = files.getFileFileName().substring(files.getFileFileName().lastIndexOf(".")+1);
		for(String s:filestype){
			if(s.equals(filetype)){
				System.out.println("������ȷ");
				String url = fileUpdate(filetype);
				nows.setImg(nows.getBigtitle()+"."+filetype);
				b=true;
			}
		}
		
		System.out.println("nows_____"+nows);
		if(b){
			if(nows.getId() == null){
				Serializable i = nowsSerivce.save(nows);
				System.out.println("û��id"+i);
			}else{
				Nows n = nowsSerivce.findById(nows.getId());
				nowsSerivce.update(nows);
			}
			ActionContext.getContext().put("nn", nows);
			return "nows_savaOrupdate";
		}else{
			return "error";
		}
	}
	
	public String list(){
		
		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String sj = dateFormat.format(now).substring(0, 10);
		System.out.println("ʱ�� ��"+sj);
		List<Nows> hotlist = nowsSerivce.findHotList();
		List<Nows> nowlist = nowsSerivce.findNowList("shijian", sj);
		ActionContext.getContext().put("hotnows", hotlist);
		ActionContext.getContext().put("nownows", nowlist);
		return "nows_list";
	}
	
	public String getEnty(){
		
		Nows n = nowsSerivce.findById(nows.getId());
		System.out.println(n);
		ActionContext.getContext().put("nn", n);
		return "nows_details";
	}
	
	public String findEnty(){
		
		ActionContext.getContext().put("pp", page);
		System.out.println("ģ����ѯ"+nows.getBigtitle());
		List<Nows> list = nowsSerivce.findEntyCondition(nows.getBigtitle(), 0);
		ActionContext.getContext().put("listname", "ȫ������");
		ActionContext.getContext().put("nowslist", list);
		return "nows_alllist";
	}
	
	public String findDeleteEnty(){
		
		ActionContext.getContext().put("pp", page);
		List<Nows> list = nowsSerivce.findEntyCondition(nows.getBigtitle(), 1);
		ActionContext.getContext().put("nowslist", list);
		ActionContext.getContext().put("listname", "ʧЧ����");
		return "nows_deletelist";
	}
	
	public String findById(){
		
		Nows n = nowsSerivce.findById(nows.getId());
		ActionContext.getContext().put("nowsedit", n);
		return "nows_edit";
	}
	
	public String findAllList(){
		
		List<Nows> lists = nowsSerivce.findZT(0);
		System.out.println("------");
		System.out.println("____-------"+page.getCurrentPage());
		page.setCurrentPage(page.countCurrentPage(page.getCurrentPage()));
		List<Nows> list = nowsSerivce.PageList(0,page.getCurrentPage());
		System.out.println("___"+list);
		int totalPage = page.countTotalPage(10, lists.size());
		page.setTotalPage(totalPage);
		ActionContext.getContext().put("alllist", lists);
		ActionContext.getContext().put("pp", page);
		ActionContext.getContext().put("nowslist", list);
		ActionContext.getContext().put("listname", "ȫ������");
		return "nows_alllist";
	}
	
	public String deletelist(){
		
		List<Nows> lists = nowsSerivce.findZT(1);
		page.setCurrentPage(page.countCurrentPage(page.getCurrentPage()));
		List<Nows> list = nowsSerivce.PageList(1,page.getCurrentPage());

		int totalPage = page.countTotalPage(2, lists.size());
		page.setTotalPage(totalPage);
		ActionContext.getContext().put("alllist", lists);
		ActionContext.getContext().put("pp", page);
		ActionContext.getContext().put("nowslist", list);
		ActionContext.getContext().put("listname", "ʧЧ����");
		return "nows_deletelist";
	}

	public String delete(){
		
		System.out.println("ɾ��ID"+nows.getId());
		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Nows n = nowsSerivce.findById(nows.getId());
		n.setZhuangtai(1);
		n.setShijian(dateFormat.format(now));
		nowsSerivce.update(n);
		return "nows_delete";
	}
	
	public String cddelete(){
		
		Nows n = nowsSerivce.findById(nows.getId());
		nowsSerivce.delete(n);
		return "nows_cddelete";
	}
	public String recovery(){
		
		Nows n = nowsSerivce.findById(nows.getId());
		n.setZhuangtai(0);
		nowsSerivce.update(n);
		return "nows_recovery";
	}
}
