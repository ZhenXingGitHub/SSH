package com.gd.action;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.gd.model.Activity;
import com.gd.model.Admin;
import com.gd.model.Nows;
import com.gd.service.AdminService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@Controller
public class AdminAction extends ActionSupport {

	private Admin admin;
	
	@Resource
	private AdminService adminService;
	
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	public String Save(){
		
		adminService.Save(admin);
		return "adminsave";
	}
	
	public String login(){
		Admin aa = new Admin();
		Admin a = adminService.findEnty(admin);
		if(a != null){
			ActionContext.getContext().getSession().put("admin", a);
			return "login";
		}
		else{
			return "login_error";
		}
	
	}
	
	public void nows(){
		
		int tn = adminService.tdnum("Nows").intValue();
		int nows = adminService.allnum("Nows").intValue();
		List<Nows> list = adminService.findHotNows();
		System.out.println("shangdu___________"+list);
		ActionContext.getContext().put("tn", tn);
		ActionContext.getContext().put("nows", nows);
		ActionContext.getContext().put("hotnows", list);
	}
	
	public void activity(){
		
		int allac = adminService.allnum("Activity").intValue();
		List<Activity> hotac = adminService.findHotAC();
		System.out.println("ac___"+allac);
		ActionContext.getContext().put("allac", allac);
		ActionContext.getContext().put("hotac", hotac);
	}
	
	public void user(){
		
		int alluser = adminService.allnum("User").intValue();
		Date now = new Date(); 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String sj = dateFormat.format(now).substring(0, 10);
		ActionContext.getContext().put("sj", sj);
		ActionContext.getContext().put("alluser", alluser);
	}
	
	public String index(){
		
		nows();
		activity();
		user();
		return "admin_login";
	}
}
